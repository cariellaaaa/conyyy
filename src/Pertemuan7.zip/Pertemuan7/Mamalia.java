/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan7;

/**
 *
 * @author raph
 */
public class Mamalia extends MahlukHidup{
    int jmlKaki;
    String Suara;
    String test;

    public Mamalia() {
        nama = "Kuda";  
    }
   
    @Override
    String bernafas() {
        return "Bernafas menggunakan Paru - Paru";
    }
    
}
